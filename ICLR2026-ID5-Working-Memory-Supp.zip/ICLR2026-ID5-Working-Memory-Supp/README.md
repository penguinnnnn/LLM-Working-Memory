# LLM-Working-Memory

## Setup

Before running the experiments, create a `.env` file in the root directory with your API keys:

```
OPENAI_API_KEY=your_openai_api_key
TOGETHER_API_KEY=your_together_api_key
```

## Experiments

This repository contains three main experiments:

### 1. `guess_numbers.py`

A task where the model guesses a number from a given range.

* Adjust the number range via the `NUMBER` variable.
* Control the number of repeated runs using the `REPEAT` variable.

### 2. `binary_search.py`

Binary search-style property inference with multiple question types.

* Use `Q_NUMBER` to set the number of questions per property.
* Use `REPEAT` to repeat the experiment multiple times.

### 3. `math_magic.py`

A task testing arithmetic and memory retention.

* Use `REPEAT` to control how many times the experiment runs.

